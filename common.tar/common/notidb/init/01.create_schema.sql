CREATE TABLE IF NOT EXISTS public.message
(
    is_read boolean,
    created_at timestamp(6) without time zone,
    message_id uuid NOT NULL DEFAULT gen_random_uuid(),
    receiver_id uuid NOT NULL,
    sender_id uuid,
    action character varying(255) COLLATE pg_catalog."default",
    content character varying(255) COLLATE pg_catalog."default",
    title character varying(255) COLLATE pg_catalog."default",
    url character varying(255) COLLATE pg_catalog."default",
    CONSTRAINT message_pkey PRIMARY KEY (message_id)
)

    TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.message
    OWNER to notification_service;