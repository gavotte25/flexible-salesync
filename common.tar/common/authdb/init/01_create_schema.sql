DROP TABLE IF EXISTS public.company CASCADE;
CREATE TABLE IF NOT EXISTS public.company
(
    company_id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    name text NOT NULL,
    avatar_url text,
    address text,
    description text,
    phone text,
    tax_code text
);


CREATE TABLE IF NOT EXISTS public.payment
(
    payment_id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    company_id uuid NOT NULL,
    by_user uuid,
    created_date date,
    duration integer,
    amount money,
    CONSTRAINT fk_relation_relation FOREIGN KEY (company_id)
        REFERENCES public.company (company_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);